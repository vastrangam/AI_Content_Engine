# MEDHAVA — the documents

Extract this whole folder and keep the structure. The markdown files show their screenshots by
relative path, so moving one file out on its own will leave its pictures behind.

## Where to start

| File | What it is |
|---|---|
| `Medhava_Build_Roadmap` | The whole life of the product in one file — the ten stages from idea to launch, then every module, every app with its real build state, and every rule in full. |
| `Medhava_BOS` | **Start here.** All four platform documents in one — the reader’s tour, the design and why, the build plan, and how it is engineered. |
| `MEDHAVA_HOW_TO_BUILD` | The ordered path from the downloaded archive to a running website, then the loop repeated once per app. The first thing to read after unzipping. |
| `START_HERE_OWNER` | The first page to open: what this project is, where it honestly stands today read from the registers, what to do in what order, and the one question to ask any tool that claims something is finished. |
| `SETUP_CHECKLIST` | What to buy and switch on, in the order it should happen, each step saying what it is for, why it sits where it does, and how you know it worked. Free options first; the one capability with no free path is last on purpose. |
| `SEVEN_STAGE_ROADMAP` | The owner’s own seven stages, in his order and his numbering, each carrying what must be true first, what it means, WHO does it, what gets done, and how you know it worked — with what exists today read from the requirements registry. |
| `WORKING_WITH_AI_TOOLS` | How to carry this project between Claude, Codex and Grok without losing anything — what to paste to start a session, what to do when a limit runs out mid-project, which tool suits which work, and the one question that keeps every one of them honest. |
| `MASTER_SPEC_COVERAGE` | Every one of the 945 line items in the master specification, counted: what is covered, what is not, and what no amount of code can close — with the mapping to a real app resolved from the requirements registry rather than typed. |
| `CONSTRAINTS` | The 85 specification lines no amount of code closes, grouped by what each one actually needs — a mail domain, a payment gateway, a carrier, a portal registration, a deployed host — with how long each takes to arrange and which lines it unblocks. |
| `MEDHAVA_CONTENTS` | Every file in MEDHAVA_BOS.zip, grouped by what it is for, each with what the file’s own header says it does and its size. Complete, not selected — the count in the heading is the length of the list below it, and a gate compares both against the real archive. |
| `CURRENT_STATE_AUDIT` | What is actually in this repository, counted at generation time rather than recalled — files, lines, tables, policies, tests, gates, and what each of them has been proven to do. |
| `PRODUCT_CAPABILITY_MATRIX` | Every module and every app with the rung it has reached and the 0–5 score that rung translates to — the same measurement as the registry, arranged by where a thing lives rather than by what proves it. |
| `GAP_ANALYSIS` | What is missing, what waits behind it, and which gaps a commit cannot close at all — the joins between the other registers, which is where the findings that matter actually live. |
| `BUILD_QUEUE` | What to build next, as independently verifiable vertical slices, each carrying its risk, complexity, acceptance criteria, test and verification plan, required evidence, blockers — and the argument for why it sits where it does in the order. |
| `REQUIREMENTS_REGISTRY` | What is standing up, what is only written down, and the recorded command that proves each one — one row per app and per capability, with the rungs nothing here has earned left visibly empty. |
| `MEDHAVA_PLAN_OF_ACTION` | The plan of action on its own: what is built, in what order, and the rules it must satisfy. |
| `MEDHAVA_ARCHITECT` | What the system is and why it is shaped this way — every decision, its reason, and what would make it the wrong one. |
| `MEDHAVA_BUILD_GUIDE` | How the platform is engineered — architecture, database, backend, frontend, storage, sign-in, integrations, running it. |
| `brand/delivery/website/MEDHAVA_BOS/Medhava_Website` | The website as a document: the designed page, printed. |
| `DEPLOYMENT` | The server runbook: putting the platform on a machine and keeping it there. |

Every document is here twice: a `.pdf` to read and print, and a `.md` twin carrying the same
content as plain text, for searching, sending, or pasting elsewhere.

## THIS ARCHIVE IS FOR READING, NOT FOR BUILDING

**Do not hand this zip to a coding agent and ask it to build.** It carries documents and PDFs, and
no source: no schema, no engine, no tests, no package file. Checked rather than assumed — extracting
it and testing the build prompt against it found **18 of 22 paths absent and every command broken**,
with nothing to tell the agent why.

To build, give the agent the **repository**. The prompt below checks this in its first section and
stops if it has the wrong thing.

## Where to start building

`MEDHAVA_BOS_PROMPT.md` is the one to open first if you are going to build this. Paste it at the start of
a session with Claude Code or Codex: it says what already exists in the repository, what does not,
the order to build in, the gates that must not be weakened, and what to do first. The standing brief for building the platform: what exists, what does not, the phase order, the gates, and what to do first.

Section 0 of it gets something on screen in a browser before anything is changed.

## The skill

`MEDHAVA_BOS.SKILL.md` is not for reading. It is for handing to an agent — Claude Code, Codex, anything
that reads a folder and writes code — which then knows what to read first, what order to work in,
and the command that decides each phase. Read by an agent to build the platform from nothing: what to read first, the order of work, and the command that decides each phase.

Every path and every command inside it was checked to exist before it was written.

## About the screenshots

Every screen is a real render of the software — the same markup and the same stylesheet the
product uses, not a drawing of it. **The figures on them are illustrative**: representative
examples, not a photograph of anyone's live data.

Generated by `brand/delivery/website/mkbundle.js`. Nothing in here is maintained by hand.
