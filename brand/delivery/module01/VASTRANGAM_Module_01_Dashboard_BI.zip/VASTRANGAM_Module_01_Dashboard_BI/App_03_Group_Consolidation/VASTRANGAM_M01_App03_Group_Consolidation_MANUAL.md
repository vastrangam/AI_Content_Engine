# Group Consolidation — Complete Manual
### Medhava · Vastrangam — its own companies, mills and marketplaces
**Module 01 · Dashboard & BI — App 3 of 4**

The whole manual is in the block below. Copy it, print it, or send it to
whoever is going to use the app — it assumes no technical knowledge at all.

```text
════════════════════════════════════════════════════════════════════════

   M E D H A V A  ·  GROUP CONSOLIDATION
   Vastrangam — its own companies, mills and marketplaces
   Module 01 · Dashboard & BI — App 3 of 4

   COMPLETE MANUAL — written for someone who has never installed
   business software before. No technical knowledge assumed.

════════════════════════════════════════════════════════════════════════


WHAT THIS APP IS

Group Consolidation adds every company you run into one set of figures.

That sounds simple, and it is where most software quietly goes wrong.
Three things have to be true before a group total means anything, and
this app enforces all three itself rather than describing them in a
manual and hoping:

  1. What your companies billed each other comes back out.
  2. A company with no tax registration still counts — and still cannot
     file a return.
  3. A name you sell under is not a company.

Part 3 explains all three properly. Part 4 walks the screens.

It is one file. It opens by double-clicking. It works with the internet
switched off. It saves your work automatically. It checks its own
arithmetic 34 different ways every time it starts.


WHAT IS IN THIS MANUAL

   PART 1   Getting it running — Windows, Mac, Android, iPhone
   PART 2   The parts of the screen
   PART 3   Screen by screen — every button, what it does
   PART 4   Connectors — nothing here is locked to one company
   PART 5   Your data — where it lives, backups, moving devices
   PART 6   Is it working properly? (the self-tests)
   PART 7   If something goes wrong
   PART 8   What this app does NOT do


════════════════════════════════════════════════════════════════════════
PART 1 · GETTING IT RUNNING
════════════════════════════════════════════════════════════════════════

WHAT YOU NEED
  Nothing to buy. Nothing to install. No internet after you have the file.
  You need one thing only: a web browser. Chrome, Edge, Safari or Firefox —
  any of them, any version from the last few years.

  There is no setup wizard, no licence key, no account, no sign-up.
  The whole app is ONE file: Group_Consolidation.html
  About 141 KB — smaller than a photo from your phone.


ON A WINDOWS COMPUTER
  1. Find the file Group_Consolidation.html — usually in your Downloads folder.
     (If it came inside a ZIP, right-click the ZIP → "Extract All" first.
      You must extract it. Opening the file from inside the ZIP will not work
      properly, because Windows opens it in a temporary place.)
  2. Double-click Group_Consolidation.html.
  3. It opens in your browser. That is the whole app. You are done.

  If it opens in Notepad instead of a browser:
     right-click the file → "Open with" → choose Chrome or Edge →
     tick "Always use this app".

  To keep it handy: right-click the file → "Send to" → "Desktop (create shortcut)".
  Now it is an icon on your desktop, exactly like any other program.


ON A MAC
  1. Find Group_Consolidation.html in Downloads. If it came in a ZIP, double-click the ZIP
     to unpack it first.
  2. Double-click Group_Consolidation.html. Safari opens it.
  3. Done.

  To keep it handy: drag the file onto your Dock, or right-click →
  "Make Alias" and drag the alias to your desktop.


ON AN ANDROID PHONE OR TABLET
  1. Save Group_Consolidation.html to your phone. Any route works — WhatsApp, email,
     Google Drive, or a USB cable from your computer.
  2. Open the "Files" app (some phones call it "My Files").
  3. Go to Downloads and tap Group_Consolidation.html.
  4. If the phone asks how to open it, choose Chrome.
  5. Done. The app fills the screen and the menu is behind the ☰ button
     at the top-left.

  MAKE IT LOOK AND FEEL LIKE A REAL APP:
     With the app open in Chrome, tap ⋮ (three dots, top-right) →
     "Add to Home screen" → give it a name → "Add".
     Now there is an icon on your home screen. Tapping it opens
     Group Consolidation directly, with no browser bar. Exactly like any other app,
     and it still works with the phone in flight mode.


ON AN IPHONE OR IPAD
  1. Save Group_Consolidation.html to the "Files" app (Save to Files from WhatsApp, Mail
     or wherever you received it).
  2. Open the Files app, find it, and tap it. Safari opens it.
  3. Done.

  MAKE IT LOOK AND FEEL LIKE A REAL APP:
     With the app open in Safari, tap the Share button (the square with
     the arrow pointing up) → scroll down → "Add to Home Screen" → "Add".
     Now Group Consolidation has its own icon on your home screen.

  Note for iPhone: iPhones are stricter about files opened straight from
  the Files app. If your data does not survive closing the app, do this
  instead — put the file in iCloud Drive or Google Drive, open it from
  there in Safari, then "Add to Home Screen". After that it behaves
  normally.


WHAT ABOUT THE INTERNET?
  You do not need it. Once the file is on your device, the app works with
  the WiFi off, on a plane, in a shop with no signal. It never sends your
  numbers anywhere, because there is nowhere for them to be sent to. There
  is no server behind this app.


SHARING IT WITH SOMEONE ELSE
  Send them the file. WhatsApp, email, a pen drive — anything. They do the
  same three steps and they have their own copy.
  Their copy starts with the demo data. It does NOT contain your figures.
  Data never travels with the file — only with a backup you export on purpose
  (see PART 4).


════════════════════════════════════════════════════════════════════════
PART 2 · THE PARTS OF THE SCREEN
════════════════════════════════════════════════════════════════════════

  TOP BAR       The Medhava mark, the app name, then two grey pills:
                the company (Vastrangam) and the financial year (FY 2026-27).

  LEFT MENU     Six screens:
                  THE GROUP   Group figures · Company by company ·
                              Between your companies
                  SET UP      Companies & names · Who may file
                  WIRING      Wiring
                  CONNECTORS  Connectors
                  SYSTEM      Backup & Health

  PERIOD ROW    April · May · June · July · Full year.
                There is NO company dial in this app, on purpose — this
                app's whole job is all of your companies at once. Every
                table here already has one row per company.


════════════════════════════════════════════════════════════════════════
PART 3 · THE THREE RULES THIS APP EXISTS TO ENFORCE
════════════════════════════════════════════════════════════════════════

Adding up several companies is easy. Adding them up HONESTLY takes three
rules, and this app enforces all three itself — they are not policies
somebody has to remember on a busy Friday.

RULE 1 · WHAT YOUR COMPANIES BILLED EACH OTHER COMES BACK OUT
  A group cannot sell to itself. Here, Adini Couture does the stitching for the other
  two companies and invoices them for it.
  That bill is completely real for the company that raised it and for the
  company that paid it. It is not revenue for the group.

  It comes out of group sales AND out of group purchases — and it never
  touches group profit, because it was income to one and a cost to another,
  so the two halves already cancelled.

RULE 2 · A COMPANY WITH NO TAX REGISTRATION IS STILL A COMPANY
  Adini Couture has no GSTIN of its own — it only does job work for
  Ethnic Fashion and Vastrangam.
  It counts in every group figure — sales, costs, cash, stock, all of it.
  And it is REFUSED entry to a tax return.

  Those are two different questions. Most software answers both the same
  way: say "no" to both and you lose a real company out of your group
  figures; say "yes" to both and you file something you should not have.

RULE 3 · A NAME YOU SELL UNDER IS NOT A COMPANY
  "Adini" is a Flipkart seller name belonging to the
  Vastrangam company. Every order under it is invoiced as Vastrangam.
  (Adini COUTURE, confusingly, IS a separate company. Both facts are true
  at once, and this app keeps them apart.)
  Making it a company of its own would count the same orders twice, in
  group sales, in group profit, and in every share you quote. So it is
  refused — and you can try it yourself, see Screen 4.


════════════════════════════════════════════════════════════════════════
PART 4 · SCREEN BY SCREEN
════════════════════════════════════════════════════════════════════════

──────────────────────────────────────────────
SCREEN 1 · GROUP FIGURES
──────────────────────────────────────────────
FIVE CARDS: group net sales (after removing internal billing), group profit,
group cash, group stock, and how many companies there are — with how many of
them have a registration.

THE LEFT PANEL IS THE WHOLE POINT OF THIS APP.
  It does not just show you the group total. It shows the total BEING
  ARRIVED AT, line by line:

       Every company's net sales, added up
     − What your companies billed each other
     = Group net sales

       Every company's purchases, added up
     − The same internal billing, on the buying side
     = Group purchases

     − Making / wages
     − Running costs
     = Group profit

  Notice the elimination appears twice and cancels itself. That is the point.

  A consolidated figure you cannot reconstruct is a figure you cannot defend
  to a bank, a buyer or an auditor.

THE RIGHT PANEL shows where the sales came from, company by company, and
then two lines that are worth reading together:
     Sold outside the group          ← business you won
     Billed between your own companies ← work moving inside the group
  Only the first one grows the business.

──────────────────────────────────────────────
SCREEN 2 · COMPANY BY COMPANY
──────────────────────────────────────────────
One row per company: net sales, purchases, wages, running costs, profit,
margin, and whether it can file a return.

A group total is an average with the arguments removed. This screen puts
them back.
  · A company with good sales and a NEGATIVE margin is being carried.
  · A company with cash and no stock is a trading arm; one with stock and
    no cash is a making arm. Do not judge them by the same margin.
  · Balances do not move when you change the period — they are positions.

The "Added together" line at the bottom is the group figure BEFORE the
elimination. The gap between that and the headline on Screen 1 is exactly
what your companies billed each other.

──────────────────────────────────────────────
SCREEN 3 · BETWEEN YOUR OWN COMPANIES
──────────────────────────────────────────────
Every internal invoice in the period, and — side by side — the two group
sales figures: the one without the removal, and the one with it.

This is how a group quotes a turnover far larger than it earned without
anybody lying. Nobody removed the internal billing.

It is never hidden, either. An internal invoice travels on its own channel
so it can be separated — but it stays on the books of the company that
raised it, because for that company it is the whole living.

──────────────────────────────────────────────
SCREEN 4 · COMPANIES & NAMES
──────────────────────────────────────────────
FOUR CARDS: how many companies, how many your plan covers, how much room is
left, and how many trading names.

  ADD A COMPANY
    Short code, name, tax registration (LEAVE IT EMPTY if it has none),
    and what it does. Press "Add company".

    A company with no registration is perfectly normal — a job-work arm,
    a new venture, a branch that bills through another.

  REMOVE A COMPANY
    Refused if it still has records against it, and the refusal tells you
    how many. Those records would be left belonging to nobody and every
    group figure would quietly change. Move or delete them first.

  THE BUTTON WORTH PRESSING: "Try making this a company"
    It sits on every trading name. Press it. It refuses, and the refusal
    explains that those orders are already counted under the company the
    name belongs to.

    That button is there on purpose. A rule you can read is a rule you half
    believe; a rule you can try to break, and watch refuse, is one you
    understand.

  HOW MANY COMPANIES YOU MAY HAVE
    The software sets NO limit. Your plan does. Fill the plan up and try
    to add one more: the refusal names the plan and says the software has
    no limit of its own.

──────────────────────────────────────────────
SCREEN 5 · WHO MAY FILE
──────────────────────────────────────────────
Every company, with its registration, its net sales for the period, a
column that says "always" under "Counts in group figures", and a button.

  On a REGISTERED company:  press it and you get that company's own
                            figures — gross, returns, net, purchases.
                            Its own, not the group's, because a return is
                            filed by a company and not by a group.

  On an UNREGISTERED one:   press it and it REFUSES, in words, with the
                            reason. This is the app doing its job. A return
                            filed for a company that has no registration is
                            not a small mistake — it is a filing in somebody
                            else's name.

WHEN THE COMPANY DOES GET REGISTERED
  Put the number on it in Companies & names. Nothing else changes: same
  records, same group figures, and from that moment it can build a return.
  No migration, no re-entry, no second company.

──────────────────────────────────────────────
SCREEN 6 · WIRING · and SCREEN 7 · BACKUP & HEALTH
──────────────────────────────────────────────
Wiring lists every group figure, its source and its arithmetic, plus the
three rules in one place. Backup & Health is covered in PART 5 and PART 6.


════════════════════════════════════════════════════════════════════════
PART 4 · CONNECTORS — NOTHING HERE IS LOCKED TO ONE COMPANY
════════════════════════════════════════════════════════════════════════

This is a promise, and it is checked by the app itself every time it opens:

    NO MEDHAVA APP DEPENDS ON ANY SINGLE OUTSIDE SERVICE.

Not on one accounting package. Not on one marketplace. Not on one AI company.
Not on one automation tool. Not on one courier. Ever.

Open the **Connectors** screen (left menu) and you can see it for yourself.


WHAT THE SCREEN SHOWS

  Capabilities used            The outside things this app can talk to.
                               Group Consolidation uses 5.
  Alternatives available       How many different options you can pick from
                               across those capabilities — 43 in this app.
  Outside services required    ZERO. Always. That is the point.
  Running with nothing connected
                               Whether the app works right now with nothing
                               plugged in at all. It always can.

Then one panel per capability. Every option is a button — click it and you have
switched. Each option carries a tag telling you what kind of thing it is:

    built in      Ships inside Medhava. Needs nothing, costs nothing,
                  works offline.
    you host it   You run it on your own machine or your own server.
                  Your data never leaves your control.
    their cloud   Somebody else's service. Connected with a scoped,
                  revocable key — never your account password.
    by hand       A person does it, or a CSV file goes in and out.


THE THREE RULES THE APP CHECKS ON ITSELF

  1. NO CAPABILITY HAS ONLY ONE CHOICE.
     Every one has at least three. Usually eight to twelve.

  2. EVERY CAPABILITY HAS A "BUILT IN" OR "BY HAND" OPTION.
     Which means the app is fully usable with nothing connected — no
     account anywhere, no internet, no subscription. That is how it
     ships, out of the box.

  3. EVERY CAPABILITY HAS AN OPTION YOU CAN HOST YOURSELF.
     So you are never forced to send your business data to somebody
     else's cloud, whatever the fashion of the day is.

  You can read the result of all three on the Backup & Health screen —
  they are ordinary self-tests, listed in plain English with the rest.


A FEW EXAMPLES OF WHAT THAT MEANS IN PRACTICE

  Books & ledger      Medhava's own ledger · Tally · BUSY · Marg · Zoho Books ·
                      QuickBooks · ERPNext (self-hosted) · plain CSV to your CA
  Sales channels      Type them in · CSV import · Amazon · Flipkart · Myntra ·
                      Meesho · Ajio · Nykaa · JioMart · Shopify · WooCommerce ·
                      your own self-hosted store
  AI writing          Medhava templates (no AI at all) · Ollama on your own
                      machine · self-hosted Llama or Mistral · Claude · GPT ·
                      Gemini · DeepSeek · Groq · or write it yourself
  AI images           Upload your own · Stable Diffusion on your own machine ·
                      Flux · Midjourney · OpenAI · Imagen · Firefly · Canva ·
                      Medhava Image Studio
  Automation          Medhava Rules (built in) · n8n on your own server ·
                      Node-RED · Windmill · Airflow · n8n Cloud · Make ·
                      Zapier · Pipedream · cron + webhook · or by hand
  Couriers            Type the AWB in · your own delivery · Delhivery ·
                      Blue Dart · DTDC · Ecom · XpressBees · India Post ·
                      Shiprocket · NimbusPost
  Payments            Cash · UPI direct with your own QR (no commission) ·
                      Razorpay · PayU · Cashfree · PhonePe · Paytm · Stripe
  Backups             This device · a USB drive · MinIO or Nextcloud on your
                      own server · Google Drive · Dropbox · OneDrive · S3


TWO THINGS WORTH UNDERSTANDING

  SWITCHING A PROVIDER NEVER CHANGES A FIGURE.
    The arithmetic lives in Medhava, not in the service. Move from one
    courier to another and every past shipping record stays exactly as it
    was — only new labels come from somewhere else. There is a self-test
    for this: "switching a provider changes nothing else in your data".

  CLOUD SERVICES USE A SCOPED, REVOCABLE KEY — NEVER YOUR PASSWORD.
    A key can be limited to only what it needs, and cancelled in one click
    from the service's own side, without touching your login.
    **Medhava will never ask you for a marketplace, bank or account
    password.** If any screen ever does, it is not Medhava.


════════════════════════════════════════════════════════════════════════
PART 5 · YOUR DATA — WHERE IT LIVES, AND HOW TO KEEP IT SAFE
════════════════════════════════════════════════════════════════════════

WHERE IS MY DATA KEPT?
  Inside your own browser, on your own device. Nowhere else.
  Technically it sits in a small private store the browser keeps for this
  file, labelled "medhava_groupcons_vastrangam_v1".

  This means:
    ✓ Nobody else can see it. Not us, not anyone on the internet.
    ✓ It survives closing the app and restarting your computer.
    ✗ It does NOT travel between your laptop and your phone by itself.
    ✗ Clearing your browser's "site data" or "cookies" WILL erase it.

  So: take backups. It takes four seconds.


TAKING A BACKUP  (do this weekly — it is the single most important habit)
  1. Click "Backup & Health" in the left menu.
  2. Click "Export JSON".
  3. A file lands in your Downloads folder. That is your backup.
  Keep it somewhere safe — Google Drive, email it to yourself, a pen drive.


PUTTING A BACKUP BACK
  1. Click "Backup & Health".
  2. Click "Import JSON".
  3. Choose the backup file.
  Everything is replaced with what was in that file.


MOVING FROM YOUR COMPUTER TO YOUR PHONE (or to a new machine)
  1. On the old device: "Backup & Health" → "Export JSON".
  2. Send yourself both files — Group_Consolidation.html AND the backup.
  3. On the new device: open Group_Consolidation.html, then "Backup & Health" →
     "Import JSON" → pick the backup.
  Your work is now on the new device.


STARTING OVER
  "Reload demo data" puts back the example figures that came with the app.
  "Wipe all" empties it completely.
  Both ask you to confirm first. Neither can be undone — take a backup first.


════════════════════════════════════════════════════════════════════════
PART 6 · IS IT WORKING PROPERLY? (the self-tests)
════════════════════════════════════════════════════════════════════════

Every time Group Consolidation opens, it quietly checks its own arithmetic — 34
separate checks — before showing you anything. You can see the result:

  Click "Backup & Health" → look at the "Self-tests" panel.

You should see 34/34 pass. Each line is written in plain
language, so you can read what was actually checked. For example:

  · "removing internal billing never changes group profit"
  · "asking for its return is refused, not warned about"
  · "turning a trading name into a company is refused"
  · "the refusal blames the plan, not the software"

If you ever see a red "fail", something is wrong and the numbers on screen
should not be trusted. Take a backup, reload the file, and if it still fails,
report which line failed.

This is unusual for business software, and deliberate. Most programs ask you
to trust them. This one shows its working.


════════════════════════════════════════════════════════════════════════
PART 7 · IF SOMETHING GOES WRONG
════════════════════════════════════════════════════════════════════════

"It opens in Notepad / a text editor, not as an app."
   Right-click the file → "Open with" → Chrome or Edge.

"I double-clicked and nothing happened."
   The file is probably still inside the ZIP. Extract the ZIP first.

"My data disappeared."
   Three usual causes:
     a) You opened a different copy of the file. Each copy of the file keeps
        its own data. Keep ONE copy and always open that one.
     b) You cleared your browser history with "cookies and site data" ticked.
     c) You are browsing in Private / Incognito mode, which forgets
        everything when you close the window. Do not use Private mode.
   Restore from your last backup.

"The screen looks squashed on my phone."
   Turn the phone sideways for wide tables, or scroll the table sideways
   with your finger. The menu is behind the ☰ button.

"The numbers look wrong."
   Go to "Backup & Health" and check the self-tests. If they all pass, the
   arithmetic is right and the source figures need checking. The "Wiring"
   screen tells you exactly which figure comes from where.

"Can two people use it at once?"
   Not in this single-file version — each person has their own copy and
   their own data. Sharing between people is what the hosted version of
   Medhava is for.


════════════════════════════════════════════════════════════════════════
PART 8 · WHAT THIS APP DOES NOT DO
════════════════════════════════════════════════════════════════════════

Being straight with you about the edges:

  ✗ It does not sync between your devices on its own. Use the backup file.
  ✗ It does not have user accounts or passwords. Whoever can open your
    device can open the app.
  ✗ In this single-file version nothing is connected live to anything —
    the figures it reads are the ones held in the file. The Connectors
    screen shows every service it CAN be wired to, and the hosted version
    of Medhava is what opens those pipes. Whichever you pick, the app
    also works with none of them (see PART 4).
  ✗ It does not print a formal statutory report. It shows you what is
    happening; your accountant's software files the returns.
  ✗ It does not stop you entering something silly. It checks its own
    arithmetic, not your judgement.

Everything it DOES do is on the screens described above, and every figure
is traceable on the "Wiring" screen.


════════════════════════════════════════════════════════════════════════

   Medhava · One business. One brain.
   Module 01 · Dashboard & BI — App 3 of 4
   Vastrangam · FY 2026-27

════════════════════════════════════════════════════════════════════════
```

---

**File you need:** `Group_Consolidation.html` · opens by double-click · works offline · 34 self-tests
**Companion app in this module:** CEO Dashboard · Report Builder · and all three in one
